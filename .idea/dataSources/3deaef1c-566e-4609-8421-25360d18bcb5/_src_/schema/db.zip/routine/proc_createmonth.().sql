CREATE PROCEDURE proc_createmonth()
  BEGIN
set @dt='2013-10-01';
set @maxdate = unix_timestamp('2021-01-01');
while unix_timestamp(@dt) <= @maxdate do
	set @dt=date_add(@dt, interval 1 month);
	insert into rep_time_by_day(the_year,month_of_year,month_and_year)
	values(DATE_FORMAT(@dt,'%Y'),DATE_FORMAT(@dt,'%m'),DATE_FORMAT(@dt,'%Y-%m') );
	
end WHILE;

commit;
end;
