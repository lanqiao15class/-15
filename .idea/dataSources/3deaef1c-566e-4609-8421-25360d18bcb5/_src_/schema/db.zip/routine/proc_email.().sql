CREATE PROCEDURE proc_email()
  BEGIN
 DECLARE hasdata int default 0;
 declare done int default 0;
 DECLARE tuser_id int ;
 DECLARE strtel varchar(60);
 DECLARE  cur_log cursor for  
 select email,user_id from tmp_loginemail;
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;


    open cur_log;  
    ll:LOOP  
      fetch cur_log into strtel,tuser_id; 
	    if(done =1) THEN
				LEAVE  ll;
			end if;
 
  set hasdata=100;

  	select count(*) into hasdata from t_user where login_email = strtel;
	  if (hasdata =0) THEN
  	   update t_user set login_email= strtel where user_id= tuser_id;
		ELSE
		 insert into tmp_log values(CONCAT("exists " ,strtel ));
    end if;

   
     end loop;

  close cur_log;  
 
COMMIT;
end;
