CREATE PROCEDURE proc_insertincome(OUT icount INT)
  BEGIN
 declare done int default 0;
 DECLARE tuser_id int ;
 DECLARE tbuserid int ;
 DECLARE  cur_log cursor for  
select user_id , buserid from 
(
select a.user_id, b.user_id as buserid from t_student a
LEFT JOIN t_income_log b on (a.user_id =b.user_id and  b.pay_goal=1)
 where a.begin_studytime >='2016-01-01' and a.status >=102
) tmpa where buserid is null;

   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
  set icount= 0;

    open cur_log;  
    ll:LOOP  
      fetch cur_log into tuser_id, tbuserid; 
	    if(done =1) THEN
				LEAVE  ll;
			end if;
     set icount= icount+1;
	  
      insert into t_income_log(user_id,standard_money,pay_type,pay_goal)
     values(tuser_id,800, 1,1);    
     end loop;

  close cur_log;  
 
COMMIT;
end;
