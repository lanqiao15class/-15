CREATE PROCEDURE student_change()
  BEGIN
-- 数组循环结束标识
DECLARE done int default false;
-- 需要定义接收游标数据的变量 
DECLARE s int;-- 存储学员状态值
DECLARE u int ;-- 存储学员用户id
DECLARE isv int;-- 存储报名费值
DECLARE staCount int;-- 存储判断是否有stustatus字段
DECLARE isvCount int;-- 存储判断是否有isvTemp字段
-- 游标
DECLARE cur cursor for select status,userId,isAvaiable from lqzp.t_student;
 -- 将结束标志绑定到游标
DECLARE CONTINUE HANDLER for NOT FOUND set done=true;
-- 如果没有则添加stustatus列
  SELECT count(1) INTO staCount
    FROM information_schema.columns
    WHERE table_schema='lqzp'
    and table_name = 't_student'
    AND column_name = 'stustatus';

    IF staCount = 0 THEN    -- 如果没有记录
        -- 添加stustatus列
        ALTER TABLE lqzp.t_student add stustatus int;
    END IF;

-- 如果没有则添加isvTemp列
    SELECT count(1) INTO isvCount
    FROM information_schema.columns
     WHERE table_schema='lqzp'
    and table_name = 't_student'
    AND column_name = 'isvTemp';

    IF isvCount = 0 THEN    -- 如果没有记录
      -- 添加isvTemp列
       ALTER TABLE lqzp.t_student add isvTemp int;
     END IF;
-- 打开游标
open cur;
-- 循环开始
read_loop:LOOP
-- 提取游标里的数据
FETCH cur into s,u,isv;
-- select u;
-- 声明结束时，跳出循环
if done THEN
LEAVE read_loop;
end if;
-- 循环所做的事件
case s
WHEN '1' then  update lqzp.t_student set stustatus='101' where userId=u; -- 报名待审核
WHEN '2' then update lqzp.t_student set stustatus='103' where userId=u; -- 未开课
WHEN '3' then update lqzp.t_student set stustatus='104' where userId=u; -- 在读
WHEN '4' then update lqzp.t_student set stustatus='107' where userId=u; -- 开除
WHEN '5' then update lqzp.t_student set stustatus='108' where userId=u; -- 劝退
WHEN '6' then update lqzp.t_student set stustatus='109' where userId=u; -- 退学
WHEN '7' then update lqzp.t_student set stustatus='110' where userId=u; -- 休学
WHEN '8' then update lqzp.t_student set stustatus='106' where userId=u; -- 结业求职中
WHEN '9' then update lqzp.t_student set stustatus='112' where userId=u; -- 延期结业
WHEN '10' then update lqzp.t_student set stustatus='113' where userId=u; -- 延期就业
WHEN '11' then update lqzp.t_student set stustatus='114' where userId=u; -- 已就业
when '12' then update lqzp.t_student set stustatus='102' where userId=u; -- 未分班
when '13' then update lqzp.t_student set stustatus='101' where userId=u; -- 报名待审核
when '14' then update lqzp.t_student set stustatus='101' where userId=u;-- 报名待审核
ELSE update lqzp.t_student set stustatus='100' where userId=u; -- 未报名
end case;
-- 转换报名费
case isv
WHEN '0' then update lqzp.t_student set isvTemp='0' where userId=u;-- 未缴纳
WHEN '1' then update lqzp.t_student set isvTemp='2' where userId=u;-- 已缴纳
else update lqzp.t_student set isvTemp='3' where userId=u;-- 特批后缴
end case;
end loop;
-- 关闭游标
close cur;
-- select `status`,stustatus,isAvaiable,isvTemp from lqzp.t_student;

end;
