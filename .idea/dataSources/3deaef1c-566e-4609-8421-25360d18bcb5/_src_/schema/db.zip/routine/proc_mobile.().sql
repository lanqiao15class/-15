CREATE PROCEDURE proc_mobile()
  BEGIN
 DECLARE hasdata int default 0;
 declare done int default 0;
 DECLARE tuser_id int ;
 DECLARE strtel varchar(60);
 DECLARE  cur_log cursor for  
 select tel,user_id from tmp_logintel;
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;


    open cur_log;  
    ll:LOOP  
      fetch cur_log into strtel,tuser_id; 
	    if(done =1) THEN
				LEAVE  ll;
			end if;

  	select count(*) into hasdata from t_user where login_tel = strtel;
	  if (hasdata =0) THEN
  	   update t_user set login_tel= strtel where user_id= tuser_id;
		ELSE
		 insert into tmp_log values(CONCAT("exists " ,strtel ));
    end if;

   
     end loop;

  close cur_log;  
 
COMMIT;
end;
