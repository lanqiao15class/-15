CREATE PROCEDURE proc_reportjob()
  BEGIN
 delete from rep_fact_student_formal;
 delete from rep_fact_student_exception;
 delete from rep_fact_student_pay;
commit;
insert into rep_fact_student_formal(
stucount,
univ_code,
yearmonth,
course_type
)
select count(*) as ccc, univ_code ,  DATE_FORMAT(begin_studytime	,'%Y-%m')  as monthyear
 , course_type 
 from t_student where
 `status` >=102
group by univ_code,monthyear,course_type;



update rep_fact_student_formal a set a.time_id=(
 select b.time_id from rep_time_by_day b  
where a.yearmonth= b.month_and_year
);

-- 异常状态学员统计 。 
insert into rep_fact_student_exception(
payman,
univ_code,
yearmonth,
course_type,
nstatus,
classid
)
select count(*) as ccc, univ_code ,  DATE_FORMAT(begin_studytime	,'%Y-%m')  as monthyear
 , course_type , `status` nstatus , lq_class_id classid 
 from t_student where
 `status` in (107,108,109,110,112,113)
group by univ_code,monthyear,course_type,nstatus,classid;


update rep_fact_student_exception a set a.time_id=(
 select b.time_id from rep_time_by_day b  
where a.yearmonth= b.month_and_year
);


-- 缴费统计 

insert into rep_fact_student_pay(payman,paymoney,
univ_code,
yearmonth,costtype)
select count(*) as ccc,sum(re.receivable_money) summoney, tu.univ_code ,  re.monthyear
 ,  re.cost_type
 from t_student tu 
 INNER JOIN 
(
  select  DATE_FORMAT(create_date	,'%Y-%m')  as monthyear,  sum(receivable_money) receivable_money,receivable_userid,cost_type  from t_student_receivable_log 
  group by receivable_userid,cost_type,monthyear
)  re on  (re.receivable_userid= tu.user_id)
 group by univ_code,monthyear,cost_type;



update rep_fact_student_pay a set a.time_id=(
 select b.time_id from rep_time_by_day b  
where a.yearmonth= b.month_and_year
);

commit;
end;
