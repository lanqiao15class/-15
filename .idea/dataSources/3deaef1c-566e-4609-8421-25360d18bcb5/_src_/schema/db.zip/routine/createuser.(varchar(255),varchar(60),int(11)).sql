CREATE PROCEDURE createuser(IN in_email VARCHAR(255), IN in_realname VARCHAR(60), IN in_roleid INT)
  BEGIN
			DECLARE ucount int ;
		DECLARE newuserid int ;
      SELECT count(*) into ucount from t_user where login_email=in_email;
	    if(ucount =0) then 
			  insert into t_user(login_email, `password`,salt,`real_name` ,`email` ,create_time
			,update_time,type) values(in_email, 'C0FF9DB3EE31F6C4D9E85073B4660878','*WDLE9W^_AI',
	in_realname, in_email,NOW(), NOW(), 1);
		select LAST_INSERT_ID() into newuserid;
     insert into t_teacher(user_id,createtime,updatetime,teachtype,dep_id,level_id,station_id)
	  values(newuserid , NOW(), NOW(), 100,7,1,2);
	
   insert into sys_user_role (user_id, role_id )values(newuserid, in_roleid);

     select CONCAT('create user ok',newuserid);
	else 
		  select 'exists user';
			end if;

		
    END;
