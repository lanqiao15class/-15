CREATE FUNCTION getStudentStatus(in_oldstatus VARCHAR(20))
  RETURNS INT
  BEGIN
DECLARE nret   INT;

case in_oldstatus
WHEN '1' then  set nret = 101;
WHEN '2' then  set  nret = 103;
WHEN '3' then   set nret= 104;
WHEN '4' then   set nret= 107;
WHEN '5' then   set nret= 108;
WHEN '6' then   set nret= 109;
WHEN '7' then   set nret= 110;
WHEN '8' then   set nret= 106;
WHEN '9' then   set nret= 112;
WHEN '10' then   set nret= 113;
WHEN '11' then   set nret= 114;
WHEN '12' then   set nret= 102;
WHEN '13' then   set nret= 101;
WHEN '14' then   set nret= 101;
ELSE   set nret = 100;
end case;

RETURN(nret);
END;
