CREATE PROCEDURE lq_sql()
  BEGIN
--  班级数据迁移
delete from t_lqclass;
insert into t_lqclass(lq_class_id,class_name,start_time,close_time,monitor_id,chr_teacher_id,status,course_type,com_teacher_id,cep_teacher_id,type_pre,
graduate_time,expect_graduate_time,qq_group,
stu_count,type_real,inv_teacher_id,create_time,update_time,create_user_id,class_goal)
select tl.id, tl.className,tl.startTime,null,tl.monitorId,chr.userId,tl.status,tl.courseType,
com.userId,cep.userId,tl.typePre,tl.graduateTime,tl.graduateTime,tl.qqGroup,tl.stuCount,tl.typeReal,inv.userId,
tl.createTime,tl.updateTime,tl.createUserId,tl.class_goal
from lqzp.t_lqclass tl LEFT JOIN lqzp.t_teacher chr on tl.chrTeacherId=chr.id
LEFT JOIN lqzp.t_teacher com on tl.comTeacherId=com.id 
LEFT JOIN lqzp.t_teacher cep on tl.cepTeacherId =cep.id
LEFT JOIN lqzp.t_teacher inv on tl.invTeacherId=inv.id;


-- user数据迁移
insert into t_user(user_id,login_tel,login_email,login_lq,password,salt,real_name,sex,qq,email,tel,birth,nation,prov_code,city_code,id_card,create_time,update_time,remark,native_place,
type,nickname,photo)
select id,loginTel,loginEmail,loginLq,password,salt,realName,sex,qq,email,tel,birth,nation,provCode,cityCode,idCard,createTime,updateTime,
remark,nativePlace,ifnull(type,100),nickname,photo from lqzp.t_user ;
-- 老师数据迁移
insert into t_teacher(user_id,teach_no,createtime,updatetime,school_id,teachtype,education,major,address)
select userId,teachNo,createTime,updateTime,schoolId,IFNULL(type,100),education,major,address from lqzp.t_teacher;
-- 学员数据迁移
insert into t_student(user_id,stu_no,job_city_code,address,univ_code,school_type_code,school_prov_code,school_city_code,school_dormitory,major,school_tel,school_linkman,
inv_teacher_id,update_time,create_time,grade,status,course_type,lq_class_id,emp_time,audit_status,is_avaiable,idcard_front_img,idcard_back_img,has_paid,teacherid_inspector,
teacherid_advisor,begin_studytime,end_studytime,audit_through_time)
select s.userId,s.stuNo,s.jobCityCode,s.address,s.univCode,s.schoolTypeCode,s.schoolProvCode,s.schoolCityCode,s.schoolDormitory,s.major,s.schoolTel,s.schoolLinkman,inv.userId,
s.updateTime,s.createTime,s.grade,s.stustatus,s.courseType,IFNULL(s.lqClassId,0),s.empTime,s.auditStatus,isvTemp,s.idcardFrontImg,s.idcardBackImg,s.hasPaid,ins.userId,adv.userId,
s.begin_studytime,s.end_studytime,s.audit_through_time
 from lqzp.t_student s
 LEFT JOIN lqzp.t_teacher inv on inv.id=s.invTeacherId
 LEFT JOIN lqzp.t_teacher ins on ins.id=s.teacherid_inspector
LEFT JOIN lqzp.t_teacher adv on adv.id=s.teacherid_advisor;
-- 学员编号迁移
insert into t_stuno(course_type,course_total,years)
select courseType,courseTotal,years from lqzp.t_stuno;
-- 学员状态记录表迁移
insert into t_student_status_log(user_id,begin_time,operator_userid,remark,newstatus,inputtime,oldstatus,lqclassid)
select ts.userId,lg.begin_time,lg.operator_userid,lg.remark,
getStudentStatus(lg.newstatus),lg.inputtime,getStudentStatus(lg.oldstatus),
ts.lqClassId
from lqzp.t_student_status_log lg
LEFT JOIN lqzp.t_student ts on lg.stu_no=ts.id;
-- 学员换班记录迁移
INSERT INTO t_studentclass_log(user_id,class_id,create_time,exit_time)
select ts.userId,tlg.classId,tlg.createTime,tlg.exitTime from lqzp.t_studentclass_log tlg
LEFT JOIN lqzp.t_student ts on tlg.stuNo=ts.id;
-- 班级状态记录迁移
INSERT INTO t_class_status_log(class_id,begin_time,operator_userid,remark,newstatus,inputtime,oldstatus)
select class_id,begin_time,operator_userid,remark,newstatus,inputtime,oldstatus from lqzp.t_class_status_log;

-- 学费记录
insert into t_income_log(user_id,standard_money,favour_money,current_pay_money,last_pay_time,pay_type,pay_goal)
select userId,ts.training_fee,0,0,null,1,2  from lqzp.t_student ts  where  ts.training_fee is not NULL;

-- 报名费
insert into t_income_log(user_id,standard_money,favour_money,current_pay_money,last_pay_time,pay_type,pay_goal)
select userId,800,0,0,null,1,1  from lqzp.t_student ts  where  ts.training_fee is not NULL;

-- 老师授权
delete from sys_user_role;
insert into sys_user_role(user_id, role_id) select  te.user_id, te.teachtype from t_teacher te;

-- 设置老师的部门
update t_teacher set dep_id=7 ,level_id=1,station_id=teachtype;
-- 修改老师的默认密码 lanqiao2017
 update t_user  set `password`='C0FF9DB3EE31F6C4D9E85073B4660878', salt='*WDLE9W^_AI'
 where( `password`='B0318761FAC16A1C3BBA5D5D1246C873'
 or `password`='F0FC7C049FAEDE2BEC0782E39C2D2469'
) and type='1';



end;
