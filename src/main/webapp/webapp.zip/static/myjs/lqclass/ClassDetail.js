ClassDetail = function(){};
String.prototype.trim = function() { 
	  return this.replace(/(^\s*)|(\s*$)/g, ''); 
}; 
	

ClassDetail.init=function(canEdit,_Classid)
{
	//tab切换
	$(".tabClick a").click(function(){
		var _this=$(this).parents(".contbox");
		$(this).parents(".tabClick").find("a").removeClass("curr");
		$(this).addClass("curr");
		_this.find(".con-ggcbox").hide();
		_this.find(".con-ggcbox").eq($(this).index()).show();
	});
	//查看更多按钮点击事件
	$(".sl-down-btn").on("click",function(){
		$(this).hide();
		$(this).parents(".con-ggcbox").find(".more-list-disply").slideDown(100);
		$(this).siblings(".sl-up-btn").show();
	});
	$(".sl-up-btn").on("click",function(){
		$(this).hide();
		$(this).parents(".con-ggcbox").find(".more-list-disply").slideUp(100);
		$(this).siblings(".sl-down-btn").show();
	});
	//点击编辑icon
	if(canEdit)
	{
			$(".able-edit").click(function(e){
				console.log("edit ...");
				e.stopPropagation();
				var _this=$(this).parents(".line-item");
				$(".eidt-span").hide();
				$(".read-span").show();
				_this.find(".read-span").hide();
				_this.find(".eidt-span").show();
				if(_this.find(".eidt-span").children("input").length>0){
					_this.find(".eidt-span").children("input").focus();
				}
				//1.编辑后赋值到文本框zzh
				if($(this).children("em").html().trim()=="点击填写"||$(this).children("em").html().trim()=="暂无"){
					$(this).next("span").children("input").val("");//为空					
				}else{
					$(this).next("span").children("input").val($(this).children("em").html().trim());//赋值
				}
			});
		}else
			{
				$("div.clearfix a.able-edit").removeClass("able-edit");
			}
	
	$(".eidt-span").click(function(e){
		e.stopPropagation();
	});
	
	//===========================文本框-失去焦点提交(qq群)==========================================
	$(".eidt-span input[type='text']").blur(function(e){
		e.stopPropagation();
		var _this=$(this).parents(".line-item");
		//1.非空验证
		if($(this).val()==null||$(this).val()==""){//为空
			$(".eidt-span").hide();
			$(".read-span").show();
			_this.find(".read-span").hide();
			_this.find(".eidt-span").show();
			if(_this.find(".eidt-span").children("input")){
				_this.find(".eidt-span").children("input").focus();
			}
			//非空验证zzh
			if(_this.find(".label-text").html().replace("：","")=="技术老师"){
				_this.find(".error-tips").html("");//技术老师不进行提示
			}else if(_this.find(".label-text").html().replace("：","")=="CEP老师"){
				_this.find(".error-tips").html("");//CEP不进行提示
			}else if(_this.find(".label-text").html().replace("：","")=="职业经纪人"){
				_this.find(".error-tips").html("");//职业经济人不进行提示
			}else{
				_this.find(".error-tips").html("请输入"+_this.find(".label-text").html().replace("：",""));
			}
		}else{//不为空
			_this=$(this).parents(".line-item");
			_this.find(".read-span").show();
			_this.find(".eidt-span").hide();
			//校园结课日期
			if(_this.find(".label-text").html().replace("：","")=="校园结课日期"){
				$(".eidt-span").hide();
				$(".read-span").show();
				_this.find(".read-span").hide();
				_this.find(".eidt-span").show();
			}
			if(_this.find(".label-text").html().replace("：","")=="拟校园结课日期"){
				$(".eidt-span").hide();
				$(".read-span").show();
				_this.find(".read-span").hide();
				_this.find(".eidt-span").show();
			}
			
			//1.清空提示
			_this.find(".error-tips").html("");
			//2.定义传递的参数
			var parameterName;
			var parameterValue;
			//3.获取当前文本框的id名称
			var textId=_this.find(".eidt-span").children("input").attr("id");
			//4.验证是否相等,相等则不执行修改
			if($("#"+textId).val().trim()==$("em[name="+textId+"]").html().trim()){
				return;
			}
			//4.1验证
			var textCheck=$("#"+textId).val();
			if(textId=="qqGroup"){//qq
				if(!/^[1-9]\d{4,12}$/.test(textCheck)){
					_this.find(".read-span").hide();
					_this.find(".eidt-span").show();
					_this.find(".eidt-span").children("input").focus();
					_this.find(".error-tips").html("QQ号格式不正确");
					return;
				}
			}
			//5赋值
			parameterName=textId;
			parameterValue=$("#"+textId).val();
			//6.组装
			var data="lqClassId="+_Classid+"&"+parameterName+"="+parameterValue;
			//7.异步并回显
			$.ajax({
		    	 type:"post",
	             url:basePath+"/lqClass/editLqClassInfo.do",  
	             data:data,
	             dataType:"json",
	             success:function(data){
	         		if(data.code == 200){
	         			//8.
	         			$("em[name="+textId+"]").html(parameterValue);
         				layer.msg("修改成功");
	         		}else{
	          			layer.msg("修改失败");
	          		}
	             }
		    });
		}
	});
	$("body").click(function(e){
		$(".read-span").show();
		$(".eidt-span").hide();
	});
	//===========================================================================
		
	//===============================下拉框修改监听(班长)==========================================
	$('#monitorId').change(function(){
		//1.定义传递的参数
		var parameterName;
		var parameterValue;
		//2.获取选中的
		var monitorCode=$(this).children('option:selected').val();
		var monitorName=$(this).children('option:selected').text();
		//3.判断
// 		if(monitorName==$("em[name=monitorId]").html()||monitorCode==""){
// 			return;
// 		}else{
			parameterName="monitorId";
			parameterValue=$(this).children('option:selected').val();
// 		}
		//4.组装
		var data="lqClassId="+_Classid+"&"+parameterName+"="+parameterValue;
		//5.提交
		$.ajax({
    	  type:"post",
             url:basePath+"/lqClass/editLqClassInfo.do",  
             data:data,
             dataType:"json",
             success:function(data){
         		if(data.code == 200){
	         		$("em[name=monitorId]").html(monitorName);
         			layer.msg("修改成功");
         		}else{
          			layer.msg("修改失败");
          		}
             }
	    });
	});	
	//===============================下拉框修改监听(课程类别)==========================================
	$('#courseTypeCode').change(function(){
		//1.定义传递的参数
		var parameterName;
		var parameterValue;
		//2.获取选中的
		var courseTypeCode=$(this).children('option:selected').val();
		var courseTypeName=$(this).children('option:selected').text();
		//3.判断
		if(courseTypeName==$("em[name=courseTypeCode]").html()||courseTypeCode==""){
			return;
		}else{
			parameterName="courseTypeCode";
			parameterValue=$(this).children('option:selected').val();
		}
		//4.组装
		var data="lqClassId="+_Classid+"&"+parameterName+"="+parameterValue;
		//5.提交
		$.ajax({
    	  type:"post",
             url:basePath+"/lqClass/editLqClassInfo.do",  
             data:data,
             dataType:"json",
             success:function(data){
         		if(data.code == 200){
	         		$("em[name=courseTypeCode]").html(courseTypeName);
         			layer.msg("修改成功");
         		}else{
          			layer.msg("修改失败");
          		}
             }
    	});
	});
	//===============================下拉框修改监听(班级一级类)==========================================
	$('#typePre').change(function(){
		$("em[name=typeReal]").html("点击填写");
		$("em[name=typePre]").html($(this).children('option:selected').text());
		$.ajax({
    	  type:"post",
             url:basePath+"/student/getClassTypeReal.do",  
             data:{
            	 "typePre":$(this).children('option:selected').val()
             },
             dataType:"json",
             success:function(data){
         		if(data.code == 200){
	         		var data=data.list;
	         		var html="<option value=''> --请选择-- </option>";
         			for(var i=0;i<data.length;i++){
         				html+="<option value='"+data[i].value+"'>"+data[i].label+"</option>";
         			}
         			 $("#typeReal").html(html);
         		}else{
          			
          		}
             }
	    });
	});	
	//===============================下拉框修改监听(班级二级类)==========================================
	$('#typeReal').change(function(){
		var teal=$(this).children('option:selected').text();
		//1.组装
		var data="lqClassId="+_Classid+"&typePre="+$("#typePre").val()+"&typeReal="+$("#typeReal").val()+"";
		//2.提交
		$.ajax({
    	  type:"post",
             url:basePath+"/lqClass/editLqClassInfo.do",  
             data:data,
             dataType:"json",
             success:function(data){
         		if(data.code == 200){
	         		$("em[name=typeReal]").html(teal);
         			layer.msg("修改成功");
         		}else{
          			layer.msg("修改失败");
          		}
             }
	    });
	});	
};
